import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { setupAuth, registerAuthRoutes } from "./replit_integrations/auth";
import { isAuthenticated } from "./replit_integrations/auth";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Auth Setup
  await setupAuth(app);
  registerAuthRoutes(app);

  // Job Routes
  
  // List jobs
  app.get(api.jobs.list.path, isAuthenticated, async (req: any, res) => {
    const userId = req.user.claims.sub;
    const user = await storage.getUser(userId);
    const { status, myJobs } = req.query;

    if (myJobs === 'true') {
      if (user?.role === 'customer') {
        const jobs = await storage.getJobsByCustomer(userId);
        return res.json(jobs);
      } else {
        const jobs = await storage.getJobsByWorker(userId);
        return res.json(jobs);
      }
    }

    if (status === 'POSTED') {
      const jobs = await storage.getAvailableJobs();
      return res.json(jobs);
    }
    
    // Default fallback
    const jobs = await storage.getAvailableJobs();
    res.json(jobs);
  });

  // Get single job
  app.get(api.jobs.get.path, isAuthenticated, async (req, res) => {
    const job = await storage.getJob(Number(req.params.id));
    if (!job) {
      return res.status(404).json({ message: 'Job not found' });
    }
    res.json(job);
  });

  // Create Job
  app.post(api.jobs.create.path, isAuthenticated, async (req: any, res) => {
    try {
      const input = api.jobs.create.input.parse(req.body);
      const userId = req.user.claims.sub;
      
      const job = await storage.createJob({
        ...input,
        customerId: userId
      });
      
      res.status(201).json(job);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      throw err;
    }
  });

  // Update Status
  app.patch(api.jobs.updateStatus.path, isAuthenticated, async (req: any, res) => {
    const jobId = Number(req.params.id);
    const { status } = req.body;
    const userId = req.user.claims.sub;
    const user = await storage.getUser(userId);
    
    const job = await storage.getJob(jobId);
    if (!job) return res.status(404).json({ message: 'Job not found' });

    // Status logic validation
    if (status === 'ACCEPTED') {
      // Only workers can accept
      if (user?.role !== 'worker') return res.status(403).json({ message: 'Only workers can accept jobs' });
      // Can only accept POSTED jobs
      if (job.status !== 'POSTED') return res.status(400).json({ message: 'Job already taken' });
      
      const updated = await storage.updateJobStatus(jobId, status, userId);
      return res.json(updated);
    }

    if (status === 'IN_PROGRESS' || status === 'COMPLETED') {
      // Only the assigned worker can update these
      if (job.workerId !== userId) return res.status(403).json({ message: 'Not your job' });
      
      const updated = await storage.updateJobStatus(jobId, status);
      return res.json(updated);
    }

    if (status === 'PAID') {
      // Only customer can pay
      if (job.customerId !== userId) return res.status(403).json({ message: 'Only customer can pay' });
      
      const updated = await storage.updateJobStatus(jobId, status);
      return res.json(updated);
    }

    res.status(400).json({ message: 'Invalid status transition' });
  });

  // Update Profile
  app.patch(api.users.updateProfile.path, isAuthenticated, async (req: any, res) => {
    const userId = req.user.claims.sub;
    const input = api.users.updateProfile.input.parse(req.body);
    
    const updatedUser = await storage.updateUserProfile(userId, input);
    res.json(updatedUser);
  });

  // Seed Data (if empty)
  const existingJobs = await storage.getAvailableJobs();
  if (existingJobs.length === 0) {
    const dummyCustomer = await storage.upsertUser({
      id: "dummy-customer-1",
      email: "customer@example.com",
      firstName: "Alice",
      lastName: "Doe",
      role: "customer",
      profileImageUrl: "https://api.dicebear.com/7.x/avataaars/svg?seed=Alice"
    });
    
    await storage.createJob({
      customerId: dummyCustomer.id,
      title: "Fix leaking sink",
      description: "My kitchen sink is leaking water everywhere. Need urgent help.",
      location: "Downtown, Main St",
      category: "Plumbing",
      budget: 50,
      urgency: "urgent",
      status: "POSTED"
    });

    await storage.createJob({
      customerId: dummyCustomer.id,
      title: "Install ceiling fan",
      description: "Need to replace an old light fixture with a new ceiling fan.",
      location: "Westside",
      category: "Electrical",
      budget: 80,
      urgency: "normal",
      status: "POSTED"
    });
    
    console.log("Seeded database with dummy jobs");
  }

  return httpServer;
}
