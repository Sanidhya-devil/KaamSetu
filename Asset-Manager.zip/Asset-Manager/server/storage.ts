import { db } from "./db";
import {
  users, jobs,
  type User, type UpsertUser,
  type Job, type InsertJob
} from "@shared/schema";
import { eq, desc, and, or } from "drizzle-orm";
import { IAuthStorage } from "./replit_integrations/auth/storage";

export interface IStorage extends IAuthStorage {
  // Jobs
  createJob(job: InsertJob & { customerId: string }): Promise<Job>;
  getJob(id: number): Promise<Job | undefined>;
  getJobsByCustomer(userId: string): Promise<Job[]>;
  getJobsByWorker(userId: string): Promise<Job[]>;
  getAvailableJobs(): Promise<Job[]>;
  updateJobStatus(id: number, status: string, workerId?: string): Promise<Job>;
  
  // Profile
  updateUserProfile(userId: string, data: Partial<User>): Promise<User>;
}

export class DatabaseStorage implements IStorage {
  // Auth Storage Implementation
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }
  
  async updateUserProfile(userId: string, data: Partial<User>): Promise<User> {
    const [user] = await db
      .update(users)
      .set(data)
      .where(eq(users.id, userId))
      .returning();
    return user;
  }

  // Job Storage Implementation
  async createJob(job: InsertJob & { customerId: string }): Promise<Job> {
    const [newJob] = await db.insert(jobs).values(job).returning();
    return newJob;
  }

  async getJob(id: number): Promise<Job | undefined> {
    const [job] = await db.select().from(jobs).where(eq(jobs.id, id));
    return job;
  }

  async getJobsByCustomer(userId: string): Promise<Job[]> {
    return await db.select()
      .from(jobs)
      .where(eq(jobs.customerId, userId))
      .orderBy(desc(jobs.createdAt));
  }

  async getJobsByWorker(userId: string): Promise<Job[]> {
    return await db.select()
      .from(jobs)
      .where(eq(jobs.workerId, userId))
      .orderBy(desc(jobs.createdAt));
  }

  async getAvailableJobs(): Promise<Job[]> {
    return await db.select()
      .from(jobs)
      .where(eq(jobs.status, "POSTED"))
      .orderBy(desc(jobs.createdAt));
  }

  async updateJobStatus(id: number, status: string, workerId?: string): Promise<Job> {
    const updateData: any = { status };
    if (workerId) {
      updateData.workerId = workerId;
    }
    
    const [job] = await db
      .update(jobs)
      .set(updateData)
      .where(eq(jobs.id, id))
      .returning();
    return job;
  }
}

export const storage = new DatabaseStorage();
