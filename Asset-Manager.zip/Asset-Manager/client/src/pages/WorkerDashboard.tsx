import { useState } from "react";
import { useJobs } from "@/hooks/use-jobs";
import { JobCard } from "@/components/JobCard";
import { Loader2, SearchX } from "lucide-react";
import { Navigation } from "@/components/Navigation";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { motion } from "framer-motion";

export default function WorkerDashboard() {
  const [activeTab, setActiveTab] = useState("available");
  
  // We fetch both, React Query will cache them efficiently
  // Ideally, we'd only fetch the active tab's data
  const { data: availableJobs, isLoading: loadingAvailable } = useJobs({ status: 'POSTED' });
  const { data: myJobs, isLoading: loadingMyJobs } = useJobs({ myJobs: true });

  const isLoading = activeTab === "available" ? loadingAvailable : loadingMyJobs;
  const jobs = activeTab === "available" ? availableJobs : myJobs;

  return (
    <div className="min-h-screen bg-background pb-20">
      <Navigation />
      
      <main className="container mx-auto px-4 md:px-6 pt-10">
        <div className="space-y-1 mb-8">
          <h1 className="text-3xl font-display font-bold tracking-tight">Worker Dashboard</h1>
          <p className="text-muted-foreground">Find new work or manage your current jobs.</p>
        </div>

        <Tabs defaultValue="available" onValueChange={setActiveTab} className="space-y-8">
          <TabsList className="bg-secondary/50 p-1 rounded-full h-12 w-full max-w-md">
            <TabsTrigger 
              value="available"
              className="rounded-full data-[state=active]:bg-white data-[state=active]:text-primary data-[state=active]:shadow-sm h-full w-1/2 font-medium"
            >
              Available Jobs
            </TabsTrigger>
            <TabsTrigger 
              value="my-jobs"
              className="rounded-full data-[state=active]:bg-white data-[state=active]:text-primary data-[state=active]:shadow-sm h-full w-1/2 font-medium"
            >
              My Jobs
            </TabsTrigger>
          </TabsList>

          <TabsContent value="available" className="focus-visible:outline-none">
            {isLoading ? (
              <div className="flex justify-center items-center h-64">
                <Loader2 className="w-8 h-8 animate-spin text-primary" />
              </div>
            ) : jobs?.length === 0 ? (
              <EmptyState 
                title="No jobs available right now" 
                description="Check back later for new opportunities in your area."
              />
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {jobs?.map((job) => (
                  <JobCard key={job.id} job={job} variant="worker" />
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="my-jobs" className="focus-visible:outline-none">
             {isLoading ? (
              <div className="flex justify-center items-center h-64">
                <Loader2 className="w-8 h-8 animate-spin text-primary" />
              </div>
            ) : jobs?.length === 0 ? (
              <EmptyState 
                title="You haven't accepted any jobs" 
                description="Go to 'Available Jobs' to find work and start earning."
              />
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {jobs?.map((job) => (
                  <JobCard key={job.id} job={job} variant="worker" />
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}

function EmptyState({ title, description }: { title: string; description: string }) {
  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="flex flex-col items-center justify-center text-center py-20 border-2 border-dashed border-border rounded-3xl bg-secondary/20"
    >
      <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mb-4">
        <SearchX className="w-8 h-8 text-muted-foreground" />
      </div>
      <h3 className="text-xl font-bold mb-2">{title}</h3>
      <p className="text-muted-foreground max-w-sm">
        {description}
      </p>
    </motion.div>
  );
}
