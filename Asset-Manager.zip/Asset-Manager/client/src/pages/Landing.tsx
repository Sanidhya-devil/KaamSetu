import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { ArrowRight, Hammer, Users, ShieldCheck, Star } from "lucide-react";
import { Link } from "wouter";

export default function Landing() {
  const { isAuthenticated, isLoading } = useAuth();

  // If loading, show minimal spinner
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-background selection:bg-primary/20">
      {/* Navigation */}
      <nav className="container mx-auto px-6 py-6 flex justify-between items-center">
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-accent flex items-center justify-center text-white font-bold text-xl shadow-lg shadow-primary/25">
            K
          </div>
          <span className="font-display font-bold text-2xl tracking-tight">
            Kaam<span className="text-primary">Setu</span>
          </span>
        </div>
        
        <div className="flex items-center gap-4">
          <Button 
            variant="ghost" 
            className="font-medium hover:bg-primary/5 hover:text-primary hidden md:flex"
            onClick={() => window.location.href = "/api/login"}
          >
            Log in
          </Button>
          <Button 
            className="bg-primary hover:bg-primary/90 text-white shadow-lg shadow-primary/25 rounded-full px-6"
            onClick={() => window.location.href = "/api/login"}
          >
            Get Started
          </Button>
        </div>
      </nav>

      {/* Hero Section */}
      <main className="flex-1 container mx-auto px-6 pt-12 md:pt-24 pb-16">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="space-y-8 animate-enter">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-accent/10 text-accent font-medium text-sm">
              <Star className="w-4 h-4 fill-accent" />
              <span>India's #1 Gig Platform</span>
            </div>
            
            <h1 className="font-display text-5xl md:text-7xl font-bold leading-[1.1] text-foreground">
              Connecting Skill <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary via-purple-500 to-accent">
                With Opportunity
              </span>
            </h1>
            
            <p className="text-xl text-muted-foreground md:max-w-lg leading-relaxed">
              Find reliable local workers for your needs, or earn money by offering your skilled services. Simple, secure, and fast.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 pt-4">
              <Button 
                size="lg" 
                className="bg-foreground text-background hover:bg-foreground/90 h-14 px-8 text-lg rounded-full shadow-xl"
                onClick={() => window.location.href = "/api/login"}
              >
                I want to Hire
                <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
              <Button 
                size="lg" 
                variant="outline" 
                className="h-14 px-8 text-lg rounded-full border-2 hover:bg-secondary/50"
                onClick={() => window.location.href = "/api/login"}
              >
                I want to Work
              </Button>
            </div>
            
            <div className="pt-8 flex items-center gap-8 text-sm font-medium text-muted-foreground">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-green-500" />
                Verified Workers
              </div>
              <div className="flex items-center gap-2">
                <Users className="w-5 h-5 text-blue-500" />
                10k+ Users
              </div>
            </div>
          </div>

          <div className="relative hidden md:block">
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-primary/20 rounded-full blur-[100px]" />
            <div className="relative z-10 grid gap-6 grid-cols-2">
              <div className="space-y-6 pt-12">
                {/* Hero Card 1 - Plumber */}
                <div className="glass-card p-6 rounded-3xl transform hover:-translate-y-2 transition-transform duration-300">
                  <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 mb-4">
                    <Hammer className="w-6 h-6" />
                  </div>
                  <h3 className="font-bold text-lg mb-1">Skilled Plumbers</h3>
                  <p className="text-sm text-muted-foreground">Fix leaks & pipes instantly</p>
                  <div className="mt-4 flex items-center gap-2 text-xs font-bold text-green-600 bg-green-50 px-3 py-1 rounded-full w-fit">
                    Active Now
                  </div>
                </div>
                
                {/* Hero Card 2 - Electrician */}
                <div className="glass-card p-6 rounded-3xl transform hover:-translate-y-2 transition-transform duration-300">
                  <div className="w-12 h-12 rounded-full bg-amber-100 flex items-center justify-center text-amber-600 mb-4">
                    <div className="w-6 h-6">⚡</div>
                  </div>
                  <h3 className="font-bold text-lg mb-1">Electricians</h3>
                  <p className="text-sm text-muted-foreground">Safe & certified wiring</p>
                </div>
              </div>
              
              <div className="space-y-6">
                {/* Hero Card 3 - Stats */}
                <div className="glass-card p-6 rounded-3xl transform hover:-translate-y-2 transition-transform duration-300 bg-foreground text-background border-none">
                  <div className="text-4xl font-display font-bold text-accent mb-2">4.8/5</div>
                  <p className="text-white/80">Average User Rating</p>
                  <div className="flex gap-1 mt-4">
                    {[1,2,3,4,5].map(i => <Star key={i} className="w-4 h-4 fill-accent text-accent" />)}
                  </div>
                </div>

                {/* Hero Card 4 - Cleaner */}
                <div className="glass-card p-6 rounded-3xl transform hover:-translate-y-2 transition-transform duration-300">
                  <div className="w-12 h-12 rounded-full bg-purple-100 flex items-center justify-center text-purple-600 mb-4">
                    <div className="w-6 h-6">🧹</div>
                  </div>
                  <h3 className="font-bold text-lg mb-1">Home Cleaning</h3>
                  <p className="text-sm text-muted-foreground">Sparkling clean homes</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
