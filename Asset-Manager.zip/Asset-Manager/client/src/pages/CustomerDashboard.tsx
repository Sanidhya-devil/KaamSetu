import { useJobs } from "@/hooks/use-jobs";
import { JobCard } from "@/components/JobCard";
import { CreateJobDialog } from "@/components/CreateJobDialog";
import { Loader2, ClipboardList } from "lucide-react";
import { Navigation } from "@/components/Navigation";
import { motion } from "framer-motion";

export default function CustomerDashboard() {
  const { data: jobs, isLoading } = useJobs({ myJobs: true });

  return (
    <div className="min-h-screen bg-background pb-20">
      <Navigation />
      
      <main className="container mx-auto px-4 md:px-6 pt-10">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
          <div className="space-y-1">
            <h1 className="text-3xl font-display font-bold tracking-tight">My Job Postings</h1>
            <p className="text-muted-foreground">Manage your requests and track work progress.</p>
          </div>
          <CreateJobDialog />
        </div>

        {isLoading ? (
          <div className="flex justify-center items-center h-64">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        ) : jobs?.length === 0 ? (
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="flex flex-col items-center justify-center text-center py-20 border-2 border-dashed border-border rounded-3xl bg-secondary/20"
          >
            <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mb-4">
              <ClipboardList className="w-8 h-8 text-muted-foreground" />
            </div>
            <h3 className="text-xl font-bold mb-2">No jobs posted yet</h3>
            <p className="text-muted-foreground max-w-sm mb-6">
              Create your first job posting to get help from skilled workers in your area.
            </p>
            <CreateJobDialog />
          </motion.div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {jobs?.map((job) => (
              <JobCard key={job.id} job={job} variant="customer" />
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
