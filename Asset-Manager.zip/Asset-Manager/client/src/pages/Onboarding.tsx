import { useAuth } from "@/hooks/use-auth";
import { useUpdateProfile } from "@/hooks/use-profile";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Briefcase, User } from "lucide-react";
import { useLocation } from "wouter";
import { useEffect } from "react";
import { motion } from "framer-motion";

export default function Onboarding() {
  const { user } = useAuth();
  const { mutate: updateProfile, isPending } = useUpdateProfile();
  const [, setLocation] = useLocation();

  // If user already has a role, redirect to appropriate dashboard
  useEffect(() => {
    if (user?.role === 'customer') setLocation('/customer-dashboard');
    if (user?.role === 'worker') setLocation('/worker-dashboard');
  }, [user, setLocation]);

  const handleRoleSelection = (role: 'customer' | 'worker') => {
    updateProfile(
      { role },
      {
        onSuccess: () => {
          // Navigation handled by useEffect above after user state updates
        },
      }
    );
  };

  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center p-6 relative overflow-hidden">
      {/* Decorative Background */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none">
        <div className="absolute top-[-10%] right-[-10%] w-[500px] h-[500px] bg-primary/10 rounded-full blur-[100px]" />
        <div className="absolute bottom-[-10%] left-[-10%] w-[500px] h-[500px] bg-accent/10 rounded-full blur-[100px]" />
      </div>

      <div className="z-10 max-w-4xl w-full text-center space-y-12">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="space-y-4"
        >
          <h1 className="font-display text-4xl md:text-5xl font-bold">
            Welcome, {user?.firstName}!
          </h1>
          <p className="text-xl text-muted-foreground max-w-lg mx-auto">
            To get started, please tell us how you plan to use KaamSetu.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-8 max-w-3xl mx-auto">
          {/* Customer Option */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
          >
            <Card className="p-8 h-full flex flex-col items-center text-center hover:border-primary hover:shadow-xl hover:shadow-primary/10 transition-all duration-300 cursor-pointer group bg-white/50 backdrop-blur-sm" onClick={() => handleRoleSelection('customer')}>
              <div className="w-20 h-20 rounded-full bg-blue-100 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <User className="w-10 h-10 text-blue-600" />
              </div>
              <h2 className="text-2xl font-bold mb-3">I want to Hire</h2>
              <p className="text-muted-foreground mb-8 flex-1">
                Post jobs, find local workers, and get things done around your home or office.
              </p>
              <Button 
                className="w-full bg-blue-600 hover:bg-blue-700 h-12 text-lg shadow-lg shadow-blue-600/20"
                onClick={(e) => { e.stopPropagation(); handleRoleSelection('customer'); }}
                disabled={isPending}
              >
                Join as Customer
              </Button>
            </Card>
          </motion.div>

          {/* Worker Option */}
          <motion.div
             initial={{ opacity: 0, x: 20 }}
             animate={{ opacity: 1, x: 0 }}
             transition={{ duration: 0.5, delay: 0.2 }}
          >
            <Card className="p-8 h-full flex flex-col items-center text-center hover:border-accent hover:shadow-xl hover:shadow-accent/10 transition-all duration-300 cursor-pointer group bg-white/50 backdrop-blur-sm" onClick={() => handleRoleSelection('worker')}>
              <div className="w-20 h-20 rounded-full bg-orange-100 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <Briefcase className="w-10 h-10 text-orange-600" />
              </div>
              <h2 className="text-2xl font-bold mb-3">I want to Work</h2>
              <p className="text-muted-foreground mb-8 flex-1">
                Browse available jobs, accept work, and earn money for your skills.
              </p>
              <Button 
                className="w-full bg-accent hover:bg-accent/90 h-12 text-lg shadow-lg shadow-accent/20"
                onClick={(e) => { e.stopPropagation(); handleRoleSelection('worker'); }}
                disabled={isPending}
              >
                Join as Worker
              </Button>
            </Card>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
