import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";

type Status = "POSTED" | "ACCEPTED" | "IN_PROGRESS" | "COMPLETED" | "PAID";

interface StatusBadgeProps {
  status: Status;
  className?: string;
}

export function StatusBadge({ status, className }: StatusBadgeProps) {
  const styles = {
    POSTED: "bg-blue-100 text-blue-700 hover:bg-blue-200 border-blue-200",
    ACCEPTED: "bg-amber-100 text-amber-700 hover:bg-amber-200 border-amber-200",
    IN_PROGRESS: "bg-purple-100 text-purple-700 hover:bg-purple-200 border-purple-200",
    COMPLETED: "bg-emerald-100 text-emerald-700 hover:bg-emerald-200 border-emerald-200",
    PAID: "bg-slate-100 text-slate-700 hover:bg-slate-200 border-slate-200 decoration-strikethrough",
  };

  const labels = {
    POSTED: "Open",
    ACCEPTED: "Accepted",
    IN_PROGRESS: "In Progress",
    COMPLETED: "Completed",
    PAID: "Paid & Closed",
  };

  return (
    <Badge 
      variant="outline" 
      className={cn(
        "px-2.5 py-0.5 rounded-full font-medium transition-colors border",
        styles[status] || styles.POSTED,
        className
      )}
    >
      {labels[status] || status}
    </Badge>
  );
}
