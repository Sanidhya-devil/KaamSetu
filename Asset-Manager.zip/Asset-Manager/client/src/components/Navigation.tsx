import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { LogOut, User as UserIcon, LayoutDashboard, Briefcase } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

export function Navigation() {
  const { user, logout } = useAuth();
  const [location] = useLocation();

  if (!user) return null;

  return (
    <nav className="sticky top-0 z-50 w-full border-b bg-background/80 backdrop-blur-xl supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between px-4 md:px-6">
        <Link href="/">
          <div className="flex items-center gap-2 cursor-pointer">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-primary to-accent flex items-center justify-center text-white font-bold text-lg">
              K
            </div>
            <span className="font-display font-bold text-xl tracking-tight hidden sm:inline-block">
              Kaam<span className="text-primary">Setu</span>
            </span>
          </div>
        </Link>
        
        <div className="flex items-center gap-4">
          {user.role && (
            <div className="hidden md:flex items-center gap-6 mr-4 text-sm font-medium">
              <Link href={user.role === 'customer' ? '/customer-dashboard' : '/worker-dashboard'}>
                <span className={`flex items-center gap-2 cursor-pointer transition-colors ${
                  location.includes('dashboard') ? 'text-primary' : 'text-muted-foreground hover:text-foreground'
                }`}>
                  <LayoutDashboard className="w-4 h-4" />
                  Dashboard
                </span>
              </Link>
            </div>
          )}

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="relative h-10 w-10 rounded-full ring-2 ring-primary/10 hover:ring-primary/20">
                <Avatar className="h-10 w-10">
                  <AvatarImage src={user.profileImageUrl || ""} alt={user.firstName || ""} />
                  <AvatarFallback className="bg-primary/5 text-primary font-medium">
                    {user.firstName?.charAt(0) || user.email?.charAt(0) || "U"}
                  </AvatarFallback>
                </Avatar>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="w-56" align="end" forceMount>
              <DropdownMenuLabel className="font-normal">
                <div className="flex flex-col space-y-1">
                  <p className="text-sm font-medium leading-none">{user.firstName} {user.lastName}</p>
                  <p className="text-xs leading-none text-muted-foreground">
                    {user.email}
                  </p>
                </div>
              </DropdownMenuLabel>
              <DropdownMenuSeparator />
              <div className="px-2 py-1.5 text-xs font-semibold text-primary uppercase tracking-wider bg-primary/5 rounded-sm mx-1 mb-1">
                {user.role ? `${user.role} Account` : 'No Role Selected'}
              </div>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => logout()} className="text-red-600 focus:text-red-600 cursor-pointer">
                <LogOut className="mr-2 h-4 w-4" />
                <span>Log out</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </nav>
  );
}
