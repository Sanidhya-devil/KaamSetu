import { 
  Card, 
  CardContent, 
  CardFooter, 
  CardHeader 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { StatusBadge } from "./StatusBadge";
import { MapPin, Clock, Banknote, Wrench, Briefcase, Zap, CheckCircle2, IndianRupee } from "lucide-react";
import type { Job } from "@shared/schema";
import { useUpdateJobStatus } from "@/hooks/use-jobs";
import { useAuth } from "@/hooks/use-auth";
import { motion } from "framer-motion";
import { formatDistanceToNow } from "date-fns";

interface JobCardProps {
  job: Job;
  variant: "worker" | "customer";
}

export function JobCard({ job, variant }: JobCardProps) {
  const { user } = useAuth();
  const { mutate: updateStatus, isPending } = useUpdateJobStatus();
  
  // Parse status as literal for type safety
  const status = job.status as "POSTED" | "ACCEPTED" | "IN_PROGRESS" | "COMPLETED" | "PAID";

  const handleStatusUpdate = (newStatus: typeof status) => {
    updateStatus({ id: job.id, status: newStatus });
  };

  // Determine actions based on user role and job status
  const renderActions = () => {
    if (variant === "customer") {
      if (status === "COMPLETED") {
        return (
          <Button 
            className="w-full bg-emerald-600 hover:bg-emerald-700 text-white gap-2 shadow-lg shadow-emerald-600/20"
            onClick={() => handleStatusUpdate("PAID")}
            disabled={isPending}
          >
            <Banknote className="w-4 h-4" />
            Pay ₹{job.budget}
          </Button>
        );
      }
      if (status === "PAID") {
        return (
          <Button variant="outline" className="w-full" disabled>
            Payment Completed
          </Button>
        );
      }
      return (
        <Button variant="ghost" className="w-full text-muted-foreground" disabled>
          {status === "POSTED" ? "Waiting for workers..." : "Work in progress..."}
        </Button>
      );
    }

    // Worker actions
    if (variant === "worker") {
      if (status === "POSTED") {
        return (
          <Button 
            className="w-full bg-primary hover:bg-primary/90 shadow-lg shadow-primary/25"
            onClick={() => handleStatusUpdate("ACCEPTED")}
            disabled={isPending}
          >
            Accept Job
          </Button>
        );
      }
      if (status === "ACCEPTED") {
        return (
          <Button 
            className="w-full bg-purple-600 hover:bg-purple-700 text-white gap-2 shadow-lg shadow-purple-600/20"
            onClick={() => handleStatusUpdate("IN_PROGRESS")}
            disabled={isPending}
          >
            <Zap className="w-4 h-4" />
            Start Work
          </Button>
        );
      }
      if (status === "IN_PROGRESS") {
        return (
          <Button 
            className="w-full bg-emerald-600 hover:bg-emerald-700 text-white gap-2 shadow-lg shadow-emerald-600/20"
            onClick={() => handleStatusUpdate("COMPLETED")}
            disabled={isPending}
          >
            <CheckCircle2 className="w-4 h-4" />
            Mark Complete
          </Button>
        );
      }
      if (status === "COMPLETED") {
        return (
          <Button variant="secondary" className="w-full" disabled>
            Waiting for Payment
          </Button>
        );
      }
    }
    
    return null;
  };

  const getIcon = (category: string) => {
    const icons: Record<string, any> = {
      plumbing: Wrench,
      electrical: Zap,
      cleaning: Briefcase,
    };
    const Icon = icons[category.toLowerCase()] || Briefcase;
    return <Icon className="w-5 h-5 text-primary" />;
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      <Card className="h-full flex flex-col border-border/50 hover:border-primary/20 hover:shadow-lg transition-all duration-300 group overflow-hidden">
        <div className="absolute top-0 left-0 w-1 h-full bg-gradient-to-b from-primary to-accent opacity-0 group-hover:opacity-100 transition-opacity" />
        
        <CardHeader className="space-y-4 pb-4">
          <div className="flex justify-between items-start gap-4">
            <div className="space-y-1.5">
              <div className="flex items-center gap-2 text-sm text-primary font-medium uppercase tracking-wide">
                {getIcon(job.category)}
                <span>{job.category}</span>
              </div>
              <h3 className="font-display text-xl font-bold leading-tight group-hover:text-primary transition-colors">
                {job.title}
              </h3>
            </div>
            <StatusBadge status={status} />
          </div>
        </CardHeader>
        
        <CardContent className="space-y-4 flex-1">
          <p className="text-muted-foreground line-clamp-3 text-sm leading-relaxed">
            {job.description}
          </p>
          
          <div className="grid grid-cols-2 gap-3 text-sm">
            <div className="flex items-center gap-2 text-foreground/80 bg-secondary/50 p-2 rounded-lg">
              <MapPin className="w-4 h-4 text-muted-foreground" />
              <span className="truncate">{job.location}</span>
            </div>
            <div className="flex items-center gap-2 text-foreground/80 bg-secondary/50 p-2 rounded-lg">
              <IndianRupee className="w-4 h-4 text-muted-foreground" />
              <span className="font-semibold">₹{job.budget}</span>
            </div>
            <div className="flex items-center gap-2 text-muted-foreground col-span-2 pl-2">
              <Clock className="w-3.5 h-3.5" />
              <span className="text-xs">
                Posted {formatDistanceToNow(new Date(job.createdAt || Date.now()), { addSuffix: true })}
              </span>
            </div>
          </div>
        </CardContent>
        
        <CardFooter className="pt-4 border-t border-border/50 bg-secondary/10">
          {renderActions()}
        </CardFooter>
      </Card>
    </motion.div>
  );
}
