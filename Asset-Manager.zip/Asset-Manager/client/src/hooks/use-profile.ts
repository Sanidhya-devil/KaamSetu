import { useMutation, useQueryClient } from "@tanstack/react-query";
import { api, type InsertUser } from "@shared/routes";
import { useToast } from "@/hooks/use-toast";
import { z } from "zod";

// We're picking specific fields as defined in the routes input schema
type UpdateProfileInput = Pick<z.infer<typeof InsertUser>, 'role' | 'bio' | 'skills'>;

export function useUpdateProfile() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (data: UpdateProfileInput) => {
      // Validate with the pick schema from routes definition
      const validated = api.users.updateProfile.input.parse(data);
      
      const res = await fetch(api.users.updateProfile.path, {
        method: api.users.updateProfile.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
        credentials: "include",
      });

      if (!res.ok) {
        if (res.status === 401) throw new Error("Unauthorized");
        throw new Error("Failed to update profile");
      }
      
      return api.users.updateProfile.responses[200].parse(await res.json());
    },
    onSuccess: () => {
      // Invalidate the auth user query so the app updates with new role
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      toast({
        title: "Profile Updated",
        description: "Your account is ready to go!",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}
