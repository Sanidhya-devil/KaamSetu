import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl, type InsertJob, errorSchemas } from "@shared/routes";
import { useToast } from "@/hooks/use-toast";
import { z } from "zod";

export function useJobs(filters?: { status?: string; myJobs?: boolean }) {
  const queryKey = [api.jobs.list.path, filters];
  
  return useQuery({
    queryKey,
    queryFn: async () => {
      // Build query string manually or via URLSearchParams if needed
      // Since API definition has optional input, we should check if filters exist
      const url = new URL(window.location.origin + api.jobs.list.path);
      if (filters?.status) url.searchParams.append("status", filters.status);
      if (filters?.myJobs) url.searchParams.append("myJobs", "true");
      
      const res = await fetch(url.toString(), { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch jobs");
      
      const data = await res.json();
      return api.jobs.list.responses[200].parse(data);
    },
  });
}

export function useJob(id: number) {
  return useQuery({
    queryKey: [api.jobs.get.path, id],
    queryFn: async () => {
      const url = buildUrl(api.jobs.get.path, { id });
      const res = await fetch(url, { credentials: "include" });
      if (res.status === 404) return null;
      if (!res.ok) throw new Error("Failed to fetch job");
      
      const data = await res.json();
      return api.jobs.get.responses[200].parse(data);
    },
    enabled: !!id,
  });
}

export function useCreateJob() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (data: InsertJob) => {
      const validated = api.jobs.create.input.parse(data);
      const res = await fetch(api.jobs.create.path, {
        method: api.jobs.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
        credentials: "include",
      });

      if (!res.ok) {
        if (res.status === 400) {
          const error = await res.json();
          // Try to parse with our error schema if possible
          try {
            const parsedError = errorSchemas.validation.parse(error);
            throw new Error(parsedError.message);
          } catch {
            throw new Error(error.message || "Validation failed");
          }
        }
        if (res.status === 401) throw new Error("Unauthorized");
        throw new Error("Failed to create job");
      }

      const responseData = await res.json();
      return api.jobs.create.responses[201].parse(responseData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.jobs.list.path] });
      toast({
        title: "Job Posted!",
        description: "Your job is now visible to workers nearby.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}

export function useUpdateJobStatus() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async ({ id, status }: { id: number; status: 'ACCEPTED' | 'IN_PROGRESS' | 'COMPLETED' | 'PAID' }) => {
      const url = buildUrl(api.jobs.updateStatus.path, { id });
      const res = await fetch(url, {
        method: api.jobs.updateStatus.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status }),
        credentials: "include",
      });

      if (!res.ok) throw new Error("Failed to update job status");
      
      const data = await res.json();
      return api.jobs.updateStatus.responses[200].parse(data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.jobs.list.path] });
      // Invalidate individual job too
      queryClient.invalidateQueries({ queryKey: [api.jobs.get.path] });
    },
    onError: (error) => {
      toast({
        title: "Update Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}
