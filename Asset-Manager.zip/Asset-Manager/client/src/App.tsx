import { Switch, Route, Redirect } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useAuth } from "@/hooks/use-auth";
import { useEffect } from "react";

// Pages
import Landing from "@/pages/Landing";
import Onboarding from "@/pages/Onboarding";
import CustomerDashboard from "@/pages/CustomerDashboard";
import WorkerDashboard from "@/pages/WorkerDashboard";
import NotFound from "@/pages/not-found";

function ProtectedRoute({ 
  component: Component, 
  allowedRole 
}: { 
  component: React.ComponentType, 
  allowedRole?: 'customer' | 'worker' 
}) {
  const { user, isLoading } = useAuth();

  if (isLoading) return null; // Or a loading spinner

  if (!user) {
    // Redirect to landing if not logged in
    return <Redirect to="/" />;
  }

  // If user has no role, force onboarding
  if (!user.role) {
    return <Redirect to="/onboarding" />;
  }

  // If role mismatch, redirect to correct dashboard
  if (allowedRole && user.role !== allowedRole) {
    return <Redirect to={user.role === 'customer' ? '/customer-dashboard' : '/worker-dashboard'} />;
  }

  return <Component />;
}

function Router() {
  const { user, isLoading } = useAuth();

  // Root route handler logic
  const RootHandler = () => {
    if (isLoading) return null;
    if (!user) return <Landing />;
    if (!user.role) return <Redirect to="/onboarding" />;
    if (user.role === 'customer') return <Redirect to="/customer-dashboard" />;
    return <Redirect to="/worker-dashboard" />;
  };

  return (
    <Switch>
      <Route path="/" component={RootHandler} />
      
      <Route path="/onboarding">
        {() => {
           if (isLoading) return null;
           if (!user) return <Redirect to="/" />;
           // If already has role, redirect out
           if (user.role) return <Redirect to="/" />;
           return <Onboarding />;
        }}
      </Route>

      <Route path="/customer-dashboard">
        {() => <ProtectedRoute component={CustomerDashboard} allowedRole="customer" />}
      </Route>

      <Route path="/worker-dashboard">
        {() => <ProtectedRoute component={WorkerDashboard} allowedRole="worker" />}
      </Route>

      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
