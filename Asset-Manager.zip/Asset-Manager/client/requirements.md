## Packages
framer-motion | Smooth page transitions and element animations
lucide-react | Beautiful icons for the UI (already in base, but emphasizing usage)
clsx | Utility for constructing className strings conditionally
tailwind-merge | Utility to merge Tailwind classes without conflicts

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["var(--font-display)"],
  body: ["var(--font-body)"],
}
