import { pgTable, text, serial, integer, boolean, timestamp, varchar } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { users } from "./models/auth";
import { relations } from "drizzle-orm";

export * from "./models/auth";

export const jobs = pgTable("jobs", {
  id: serial("id").primaryKey(),
  customerId: varchar("customer_id").notNull().references(() => users.id),
  workerId: varchar("worker_id").references(() => users.id), // Nullable until accepted
  
  title: text("title").notNull(),
  description: text("description").notNull(),
  location: text("location").notNull(),
  category: text("category").notNull(), // plumber, electrician, etc.
  budget: integer("budget").notNull(),
  urgency: text("urgency").notNull().default("normal"), // normal, urgent
  
  status: text("status").notNull().default("POSTED"), // POSTED, ACCEPTED, IN_PROGRESS, COMPLETED, PAID
  
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertJobSchema = createInsertSchema(jobs).omit({ 
  id: true, 
  createdAt: true, 
  workerId: true,
  status: true,
  customerId: true // inferred from session
});

export type Job = typeof jobs.$inferSelect;
export type InsertJob = z.infer<typeof insertJobSchema>;

export const jobsRelations = relations(jobs, ({ one }) => ({
  customer: one(users, {
    fields: [jobs.customerId],
    references: [users.id],
    relationName: "customerJobs"
  }),
  worker: one(users, {
    fields: [jobs.workerId],
    references: [users.id],
    relationName: "workerJobs"
  }),
}));

export const usersRelations = relations(users, ({ many }) => ({
  postedJobs: many(jobs, { relationName: "customerJobs" }),
  workedJobs: many(jobs, { relationName: "workerJobs" }),
}));
